/*
 * led_sequence.h
 *
 *  Created on: Oct 4, 2019
 *      Author: bitcraze
 */

#ifndef SRC_MODULES_INTERFACE_LED_SEQUENCE_H_
#define SRC_MODULES_INTERFACE_LED_SEQUENCE_H_

#include <stdbool.h>

extern void led_sequence (void);
void led_sequenceRun (void);

#endif /* SRC_MODULES_INTERFACE_LED_SEQUENCE_H_ */
