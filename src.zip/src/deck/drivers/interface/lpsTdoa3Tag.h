#ifndef __LPS_TDOA3_TAG_H__
#define __LPS_TDOA3_TAG_H__

#include "locodeck.h"

extern uwbAlgorithm_t uwbTdoa3TagAlgorithm;

#endif // __LPS_TDOA3_TAG_H__
